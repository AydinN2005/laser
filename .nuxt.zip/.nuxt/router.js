import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _235c4754 = () => interopDefault(import('..\\pages\\aboutUs.vue' /* webpackChunkName: "pages/aboutUs" */))
const _7107efaa = () => interopDefault(import('..\\pages\\admin\\index.vue' /* webpackChunkName: "pages/admin/index" */))
const _e01d7072 = () => interopDefault(import('..\\pages\\categoryBlog.vue' /* webpackChunkName: "pages/categoryBlog" */))
const _ccab7532 = () => interopDefault(import('..\\pages\\contactUs.vue' /* webpackChunkName: "pages/contactUs" */))
const _2f20ebc5 = () => interopDefault(import('..\\pages\\dashboard\\index.vue' /* webpackChunkName: "pages/dashboard/index" */))
const _59faea8a = () => interopDefault(import('..\\pages\\loginsignup.vue' /* webpackChunkName: "pages/loginsignup" */))
const _258ed690 = () => interopDefault(import('..\\pages\\process.vue' /* webpackChunkName: "pages/process" */))
const _4723572e = () => interopDefault(import('..\\pages\\admin\\blogs.vue' /* webpackChunkName: "pages/admin/blogs" */))
const _1c807b27 = () => interopDefault(import('..\\pages\\admin\\bodyArea.vue' /* webpackChunkName: "pages/admin/bodyArea" */))
const _7f890574 = () => interopDefault(import('..\\pages\\admin\\categories.vue' /* webpackChunkName: "pages/admin/categories" */))
const _ab8cbd68 = () => interopDefault(import('..\\pages\\admin\\comments.vue' /* webpackChunkName: "pages/admin/comments" */))
const _5b4a393e = () => interopDefault(import('..\\pages\\admin\\consultation.vue' /* webpackChunkName: "pages/admin/consultation" */))
const _73dc6166 = () => interopDefault(import('..\\pages\\admin\\data.js' /* webpackChunkName: "pages/admin/data" */))
const _2f9ddfee = () => interopDefault(import('..\\pages\\admin\\faq.vue' /* webpackChunkName: "pages/admin/faq" */))
const _2e2558a4 = () => interopDefault(import('..\\pages\\admin\\messages.vue' /* webpackChunkName: "pages/admin/messages" */))
const _a5416184 = () => interopDefault(import('..\\pages\\admin\\offDays.vue' /* webpackChunkName: "pages/admin/offDays" */))
const _de87c922 = () => interopDefault(import('..\\pages\\admin\\offers.vue' /* webpackChunkName: "pages/admin/offers" */))
const _5eede4b8 = () => interopDefault(import('..\\pages\\admin\\reservation.vue' /* webpackChunkName: "pages/admin/reservation" */))
const _df78e294 = () => interopDefault(import('..\\pages\\admin\\services.vue' /* webpackChunkName: "pages/admin/services" */))
const _79fbaf4e = () => interopDefault(import('..\\pages\\admin\\timeTable.vue' /* webpackChunkName: "pages/admin/timeTable" */))
const _931c6c40 = () => interopDefault(import('..\\pages\\admin\\users.vue' /* webpackChunkName: "pages/admin/users" */))
const _1ec6425a = () => interopDefault(import('..\\pages\\admin\\video.vue' /* webpackChunkName: "pages/admin/video" */))
const _68fc644a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _3d522048 = () => interopDefault(import('..\\pages\\admin\\singleBlog\\_id.vue' /* webpackChunkName: "pages/admin/singleBlog/_id" */))
const _e8d9281a = () => interopDefault(import('..\\pages\\admin\\singleBlogProperty\\_id.vue' /* webpackChunkName: "pages/admin/singleBlogProperty/_id" */))
const _e12eb836 = () => interopDefault(import('..\\pages\\admin\\singleService\\_id.vue' /* webpackChunkName: "pages/admin/singleService/_id" */))
const _513d844b = () => interopDefault(import('..\\pages\\admin\\singleServiceType\\_id.vue' /* webpackChunkName: "pages/admin/singleServiceType/_id" */))
const _55bffb82 = () => interopDefault(import('..\\pages\\admin\\singleUser\\_id.vue' /* webpackChunkName: "pages/admin/singleUser/_id" */))
const _05f3dc58 = () => interopDefault(import('..\\pages\\bodyArea\\_id.vue' /* webpackChunkName: "pages/bodyArea/_id" */))
const _6754b539 = () => interopDefault(import('..\\pages\\singleBlog\\_id.vue' /* webpackChunkName: "pages/singleBlog/_id" */))
const _51db1d54 = () => interopDefault(import('..\\pages\\singleService\\_id.vue' /* webpackChunkName: "pages/singleService/_id" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/aboutUs",
    component: _235c4754,
    name: "aboutUs"
  }, {
    path: "/admin",
    component: _7107efaa,
    name: "admin"
  }, {
    path: "/categoryBlog",
    component: _e01d7072,
    name: "categoryBlog"
  }, {
    path: "/contactUs",
    component: _ccab7532,
    name: "contactUs"
  }, {
    path: "/dashboard",
    component: _2f20ebc5,
    name: "dashboard"
  }, {
    path: "/loginsignup",
    component: _59faea8a,
    name: "loginsignup"
  }, {
    path: "/process",
    component: _258ed690,
    name: "process"
  }, {
    path: "/admin/blogs",
    component: _4723572e,
    name: "admin-blogs"
  }, {
    path: "/admin/bodyArea",
    component: _1c807b27,
    name: "admin-bodyArea"
  }, {
    path: "/admin/categories",
    component: _7f890574,
    name: "admin-categories"
  }, {
    path: "/admin/comments",
    component: _ab8cbd68,
    name: "admin-comments"
  }, {
    path: "/admin/consultation",
    component: _5b4a393e,
    name: "admin-consultation"
  }, {
    path: "/admin/data",
    component: _73dc6166,
    name: "admin-data"
  }, {
    path: "/admin/faq",
    component: _2f9ddfee,
    name: "admin-faq"
  }, {
    path: "/admin/messages",
    component: _2e2558a4,
    name: "admin-messages"
  }, {
    path: "/admin/offDays",
    component: _a5416184,
    name: "admin-offDays"
  }, {
    path: "/admin/offers",
    component: _de87c922,
    name: "admin-offers"
  }, {
    path: "/admin/reservation",
    component: _5eede4b8,
    name: "admin-reservation"
  }, {
    path: "/admin/services",
    component: _df78e294,
    name: "admin-services"
  }, {
    path: "/admin/timeTable",
    component: _79fbaf4e,
    name: "admin-timeTable"
  }, {
    path: "/admin/users",
    component: _931c6c40,
    name: "admin-users"
  }, {
    path: "/admin/video",
    component: _1ec6425a,
    name: "admin-video"
  }, {
    path: "/",
    component: _68fc644a,
    name: "index"
  }, {
    path: "/admin/singleBlog/:id?",
    component: _3d522048,
    name: "admin-singleBlog-id"
  }, {
    path: "/admin/singleBlogProperty/:id?",
    component: _e8d9281a,
    name: "admin-singleBlogProperty-id"
  }, {
    path: "/admin/singleService/:id?",
    component: _e12eb836,
    name: "admin-singleService-id"
  }, {
    path: "/admin/singleServiceType/:id?",
    component: _513d844b,
    name: "admin-singleServiceType-id"
  }, {
    path: "/admin/singleUser/:id?",
    component: _55bffb82,
    name: "admin-singleUser-id"
  }, {
    path: "/bodyArea/:id?",
    component: _05f3dc58,
    name: "bodyArea-id"
  }, {
    path: "/singleBlog/:id?",
    component: _6754b539,
    name: "singleBlog-id"
  }, {
    path: "/singleService/:id?",
    component: _51db1d54,
    name: "singleService-id"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
