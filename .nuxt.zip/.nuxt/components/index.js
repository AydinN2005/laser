export const ElementsBlogCard = () => import('../..\\components\\elements\\BlogCard.vue' /* webpackChunkName: "components/elements-blog-card" */).then(c => wrapFunctional(c.default || c))
export const ElementsButton = () => import('../..\\components\\elements\\Button.vue' /* webpackChunkName: "components/elements-button" */).then(c => wrapFunctional(c.default || c))
export const ElementsCheckbox = () => import('../..\\components\\elements\\Checkbox.vue' /* webpackChunkName: "components/elements-checkbox" */).then(c => wrapFunctional(c.default || c))
export const ElementsContentInput = () => import('../..\\components\\elements\\ContentInput.vue' /* webpackChunkName: "components/elements-content-input" */).then(c => wrapFunctional(c.default || c))
export const ElementsDeleteDialog = () => import('../..\\components\\elements\\DeleteDialog.vue' /* webpackChunkName: "components/elements-delete-dialog" */).then(c => wrapFunctional(c.default || c))
export const ElementsFaqCard = () => import('../..\\components\\elements\\FaqCard.vue' /* webpackChunkName: "components/elements-faq-card" */).then(c => wrapFunctional(c.default || c))
export const ElementsLoader = () => import('../..\\components\\elements\\Loader.vue' /* webpackChunkName: "components/elements-loader" */).then(c => wrapFunctional(c.default || c))
export const ElementsOfferModal = () => import('../..\\components\\elements\\OfferModal.vue' /* webpackChunkName: "components/elements-offer-modal" */).then(c => wrapFunctional(c.default || c))
export const ElementsPagination = () => import('../..\\components\\elements\\Pagination.vue' /* webpackChunkName: "components/elements-pagination" */).then(c => wrapFunctional(c.default || c))
export const ElementsRadioInput = () => import('../..\\components\\elements\\RadioInput.vue' /* webpackChunkName: "components/elements-radio-input" */).then(c => wrapFunctional(c.default || c))
export const ElementsServicesCard = () => import('../..\\components\\elements\\ServicesCard.vue' /* webpackChunkName: "components/elements-services-card" */).then(c => wrapFunctional(c.default || c))
export const ElementsTextInput = () => import('../..\\components\\elements\\TextInput.vue' /* webpackChunkName: "components/elements-text-input" */).then(c => wrapFunctional(c.default || c))
export const ElementsVerificationCode = () => import('../..\\components\\elements\\VerificationCode.vue' /* webpackChunkName: "components/elements-verification-code" */).then(c => wrapFunctional(c.default || c))
export const HelperAllHours = () => import('../..\\components\\helper\\allHours.js' /* webpackChunkName: "components/helper-all-hours" */).then(c => wrapFunctional(c.default || c))
export const HelperChooseHour = () => import('../..\\components\\helper\\ChooseHour.vue' /* webpackChunkName: "components/helper-choose-hour" */).then(c => wrapFunctional(c.default || c))
export const HelperConvertCsv = () => import('../..\\components\\helper\\convertCsv.js' /* webpackChunkName: "components/helper-convert-csv" */).then(c => wrapFunctional(c.default || c))
export const HelperCreateFormData = () => import('../..\\components\\helper\\createFormData.js' /* webpackChunkName: "components/helper-create-form-data" */).then(c => wrapFunctional(c.default || c))
export const HelperDataTable = () => import('../..\\components\\helper\\DataTable.vue' /* webpackChunkName: "components/helper-data-table" */).then(c => wrapFunctional(c.default || c))
export const HelperExportToExel = () => import('../..\\components\\helper\\exportToExel.js' /* webpackChunkName: "components/helper-export-to-exel" */).then(c => wrapFunctional(c.default || c))
export const HelperExportToPdf = () => import('../..\\components\\helper\\exportToPdf.js' /* webpackChunkName: "components/helper-export-to-pdf" */).then(c => wrapFunctional(c.default || c))
export const HelperSlider = () => import('../..\\components\\helper\\Slider.vue' /* webpackChunkName: "components/helper-slider" */).then(c => wrapFunctional(c.default || c))
export const LayoutData = () => import('../..\\components\\layout\\data.js' /* webpackChunkName: "components/layout-data" */).then(c => wrapFunctional(c.default || c))
export const LayoutFooter = () => import('../..\\components\\layout\\Footer.vue' /* webpackChunkName: "components/layout-footer" */).then(c => wrapFunctional(c.default || c))
export const LayoutFooterBottom = () => import('../..\\components\\layout\\FooterBottom.vue' /* webpackChunkName: "components/layout-footer-bottom" */).then(c => wrapFunctional(c.default || c))
export const LayoutFooterInput = () => import('../..\\components\\layout\\FooterInput.vue' /* webpackChunkName: "components/layout-footer-input" */).then(c => wrapFunctional(c.default || c))
export const LayoutMenu = () => import('../..\\components\\layout\\Menu.vue' /* webpackChunkName: "components/layout-menu" */).then(c => wrapFunctional(c.default || c))
export const LayoutMenuDropdown = () => import('../..\\components\\layout\\MenuDropdown.vue' /* webpackChunkName: "components/layout-menu-dropdown" */).then(c => wrapFunctional(c.default || c))
export const LayoutMenuMobile = () => import('../..\\components\\layout\\MenuMobile.vue' /* webpackChunkName: "components/layout-menu-mobile" */).then(c => wrapFunctional(c.default || c))
export const LayoutMobileMenuDropdown = () => import('../..\\components\\layout\\MobileMenuDropdown.vue' /* webpackChunkName: "components/layout-mobile-menu-dropdown" */).then(c => wrapFunctional(c.default || c))
export const HelperNotificationCard = () => import('../..\\components\\helper\\notification\\NotificationCard.vue' /* webpackChunkName: "components/helper-notification-card" */).then(c => wrapFunctional(c.default || c))
export const LayoutAdminANavbar = () => import('../..\\components\\layout\\admin\\ANavbar.vue' /* webpackChunkName: "components/layout-admin-a-navbar" */).then(c => wrapFunctional(c.default || c))
export const LayoutAdminASidebar = () => import('../..\\components\\layout\\admin\\ASidebar.vue' /* webpackChunkName: "components/layout-admin-a-sidebar" */).then(c => wrapFunctional(c.default || c))
export const PagesAboutContainer = () => import('../..\\components\\pages\\aboutUs\\AboutContainer.vue' /* webpackChunkName: "components/pages-about-container" */).then(c => wrapFunctional(c.default || c))
export const PagesBodyAreaAboutLaser = () => import('../..\\components\\pages\\bodyArea\\AboutLaser.vue' /* webpackChunkName: "components/pages-body-area-about-laser" */).then(c => wrapFunctional(c.default || c))
export const PagesBodyAreaAboutLeg = () => import('../..\\components\\pages\\bodyArea\\AboutLeg.vue' /* webpackChunkName: "components/pages-body-area-about-leg" */).then(c => wrapFunctional(c.default || c))
export const PagesBodyHero = () => import('../..\\components\\pages\\bodyArea\\BodyHero.vue' /* webpackChunkName: "components/pages-body-hero" */).then(c => wrapFunctional(c.default || c))
export const PagesCategoryBlogBlogs = () => import('../..\\components\\pages\\categoryBlog\\Blogs.vue' /* webpackChunkName: "components/pages-category-blog-blogs" */).then(c => wrapFunctional(c.default || c))
export const PagesCategoryBlogCBHero = () => import('../..\\components\\pages\\categoryBlog\\CBHero.vue' /* webpackChunkName: "components/pages-category-blog-c-b-hero" */).then(c => wrapFunctional(c.default || c))
export const PagesContactLeft = () => import('../..\\components\\pages\\contactUs\\ContactLeft.vue' /* webpackChunkName: "components/pages-contact-left" */).then(c => wrapFunctional(c.default || c))
export const PagesContactRight = () => import('../..\\components\\pages\\contactUs\\ContactRight.vue' /* webpackChunkName: "components/pages-contact-right" */).then(c => wrapFunctional(c.default || c))
export const PagesDashboardTabs = () => import('../..\\components\\pages\\dashboard\\DashboardTabs.vue' /* webpackChunkName: "components/pages-dashboard-tabs" */).then(c => wrapFunctional(c.default || c))
export const PagesDashboardUserReservations = () => import('../..\\components\\pages\\dashboard\\UserReservations.vue' /* webpackChunkName: "components/pages-dashboard-user-reservations" */).then(c => wrapFunctional(c.default || c))
export const PagesFaqAboutUsQuestions = () => import('../..\\components\\pages\\faq\\AboutUsQuestions.vue' /* webpackChunkName: "components/pages-faq-about-us-questions" */).then(c => wrapFunctional(c.default || c))
export const PagesFaqAllQuestions = () => import('../..\\components\\pages\\faq\\AllQuestions.vue' /* webpackChunkName: "components/pages-faq-all-questions" */).then(c => wrapFunctional(c.default || c))
export const PagesFaqHero = () => import('../..\\components\\pages\\faq\\FaqHero.vue' /* webpackChunkName: "components/pages-faq-hero" */).then(c => wrapFunctional(c.default || c))
export const PagesFaqSlider = () => import('../..\\components\\pages\\faq\\FaqSlider.vue' /* webpackChunkName: "components/pages-faq-slider" */).then(c => wrapFunctional(c.default || c))
export const PagesFaqTabs = () => import('../..\\components\\pages\\faq\\FaqTabs.vue' /* webpackChunkName: "components/pages-faq-tabs" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeBodyArea = () => import('../..\\components\\pages\\home\\BodyArea.vue' /* webpackChunkName: "components/pages-home-body-area" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeFAQ = () => import('../..\\components\\pages\\home\\FAQ.vue' /* webpackChunkName: "components/pages-home-f-a-q" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeHero = () => import('../..\\components\\pages\\home\\HomeHero.vue' /* webpackChunkName: "components/pages-home-hero" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeOurBlog = () => import('../..\\components\\pages\\home\\OurBlog.vue' /* webpackChunkName: "components/pages-home-our-blog" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeOurProcess = () => import('../..\\components\\pages\\home\\OurProcess.vue' /* webpackChunkName: "components/pages-home-our-process" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeOurServices = () => import('../..\\components\\pages\\home\\OurServices.vue' /* webpackChunkName: "components/pages-home-our-services" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeOutFeatures = () => import('../..\\components\\pages\\home\\OutFeatures.vue' /* webpackChunkName: "components/pages-home-out-features" */).then(c => wrapFunctional(c.default || c))
export const PagesHomePricing = () => import('../..\\components\\pages\\home\\Pricing.vue' /* webpackChunkName: "components/pages-home-pricing" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeSatisfaction = () => import('../..\\components\\pages\\home\\Satisfaction.vue' /* webpackChunkName: "components/pages-home-satisfaction" */).then(c => wrapFunctional(c.default || c))
export const PagesHomeWhyUs = () => import('../..\\components\\pages\\home\\WhyUs.vue' /* webpackChunkName: "components/pages-home-why-us" */).then(c => wrapFunctional(c.default || c))
export const PagesLsLogin = () => import('../..\\components\\pages\\ls\\Login.vue' /* webpackChunkName: "components/pages-ls-login" */).then(c => wrapFunctional(c.default || c))
export const PagesLsLoginWithGA = () => import('../..\\components\\pages\\ls\\LoginWithGA.vue' /* webpackChunkName: "components/pages-ls-login-with-g-a" */).then(c => wrapFunctional(c.default || c))
export const PagesLsLSTabs = () => import('../..\\components\\pages\\ls\\LSTabs.vue' /* webpackChunkName: "components/pages-ls-l-s-tabs" */).then(c => wrapFunctional(c.default || c))
export const PagesLsSignup = () => import('../..\\components\\pages\\ls\\Signup.vue' /* webpackChunkName: "components/pages-ls-signup" */).then(c => wrapFunctional(c.default || c))
export const PagesLsSLSlider = () => import('../..\\components\\pages\\ls\\SLSlider.vue' /* webpackChunkName: "components/pages-ls-s-l-slider" */).then(c => wrapFunctional(c.default || c))
export const PagesProcessBooking = () => import('../..\\components\\pages\\process\\Booking.vue' /* webpackChunkName: "components/pages-process-booking" */).then(c => wrapFunctional(c.default || c))
export const PagesProcessDailyTreatment = () => import('../..\\components\\pages\\process\\DailyTreatment.vue' /* webpackChunkName: "components/pages-process-daily-treatment" */).then(c => wrapFunctional(c.default || c))
export const PagesProcessLaserProcess = () => import('../..\\components\\pages\\process\\LaserProcess.vue' /* webpackChunkName: "components/pages-process-laser-process" */).then(c => wrapFunctional(c.default || c))
export const PagesProcessPreTreatment = () => import('../..\\components\\pages\\process\\PreTreatment.vue' /* webpackChunkName: "components/pages-process-pre-treatment" */).then(c => wrapFunctional(c.default || c))
export const PagesProcessTreatmentCard = () => import('../..\\components\\pages\\process\\TreatmentCard.vue' /* webpackChunkName: "components/pages-process-treatment-card" */).then(c => wrapFunctional(c.default || c))
export const PagesSingleBlogAuthorProfile = () => import('../..\\components\\pages\\singleBlog\\AuthorProfile.vue' /* webpackChunkName: "components/pages-single-blog-author-profile" */).then(c => wrapFunctional(c.default || c))
export const PagesSingleBlogCommentBox = () => import('../..\\components\\pages\\singleBlog\\CommentBox.vue' /* webpackChunkName: "components/pages-single-blog-comment-box" */).then(c => wrapFunctional(c.default || c))
export const PagesSingleBlogComments = () => import('../..\\components\\pages\\singleBlog\\Comments.vue' /* webpackChunkName: "components/pages-single-blog-comments" */).then(c => wrapFunctional(c.default || c))
export const PagesSingleBlogSBHero = () => import('../..\\components\\pages\\singleBlog\\SBHero.vue' /* webpackChunkName: "components/pages-single-blog-s-b-hero" */).then(c => wrapFunctional(c.default || c))
export const PagesSingleServiceBookingCard = () => import('../..\\components\\pages\\singleService\\BookingCard.vue' /* webpackChunkName: "components/pages-single-service-booking-card" */).then(c => wrapFunctional(c.default || c))
export const PagesSingleServiceReplyBox = () => import('../..\\components\\pages\\singleService\\ReplyBox.vue' /* webpackChunkName: "components/pages-single-service-reply-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBlogsAddBlogPropertyBox = () => import('../..\\components\\pages\\admin\\blogs\\AddBlogPropertyBox.vue' /* webpackChunkName: "components/pages-admin-blogs-add-blog-property-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBlogsAddBlogsBox = () => import('../..\\components\\pages\\admin\\blogs\\AddBlogsBox.vue' /* webpackChunkName: "components/pages-admin-blogs-add-blogs-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBlogsProperty = () => import('../..\\components\\pages\\admin\\blogs\\BlogsProperty.vue' /* webpackChunkName: "components/pages-admin-blogs-property" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBodyAreaAddAreaProperty = () => import('../..\\components\\pages\\admin\\bodyArea\\AddAreaProperty.vue' /* webpackChunkName: "components/pages-admin-body-area-add-area-property" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBodyAreaAddBodyAreaBox = () => import('../..\\components\\pages\\admin\\bodyArea\\AddBodyAreaBox.vue' /* webpackChunkName: "components/pages-admin-body-area-add-body-area-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBodyAreaProperty = () => import('../..\\components\\pages\\admin\\bodyArea\\BodyAreaProperty.vue' /* webpackChunkName: "components/pages-admin-body-area-property" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBodyAreaEditAreaPropertyBox = () => import('../..\\components\\pages\\admin\\bodyArea\\EditAreaPropertyBox.vue' /* webpackChunkName: "components/pages-admin-body-area-edit-area-property-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminBodyAreaEditBodyAreaBox = () => import('../..\\components\\pages\\admin\\bodyArea\\EditBodyAreaBox.vue' /* webpackChunkName: "components/pages-admin-body-area-edit-body-area-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminCategoriesAddCategoryBox = () => import('../..\\components\\pages\\admin\\categories\\AddCategoryBox.vue' /* webpackChunkName: "components/pages-admin-categories-add-category-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminCategoriesEditCategoryBox = () => import('../..\\components\\pages\\admin\\categories\\EditCategoryBox.vue' /* webpackChunkName: "components/pages-admin-categories-edit-category-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminFaqAddFaqBox = () => import('../..\\components\\pages\\admin\\faq\\AddFaqBox.vue' /* webpackChunkName: "components/pages-admin-faq-add-faq-box" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminButton = () => import('../..\\components\\pages\\admin\\helper\\AdminButton.vue' /* webpackChunkName: "components/pages-admin-button" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminHelperBigLoader = () => import('../..\\components\\pages\\admin\\helper\\BigLoader.vue' /* webpackChunkName: "components/pages-admin-helper-big-loader" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminOffDaysAddOffDay = () => import('../..\\components\\pages\\admin\\offDays\\AddOffDay.vue' /* webpackChunkName: "components/pages-admin-off-days-add-off-day" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminReservationAddReservation = () => import('../..\\components\\pages\\admin\\reservation\\AddReservation.vue' /* webpackChunkName: "components/pages-admin-reservation-add-reservation" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesAddPropertyImages = () => import('../..\\components\\pages\\admin\\services\\AddPropertyImages.vue' /* webpackChunkName: "components/pages-admin-services-add-property-images" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesAddService = () => import('../..\\components\\pages\\admin\\services\\AddService.vue' /* webpackChunkName: "components/pages-admin-services-add-service" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesAddServiceProperty = () => import('../..\\components\\pages\\admin\\services\\AddServiceProperty.vue' /* webpackChunkName: "components/pages-admin-services-add-service-property" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesAddServiceType = () => import('../..\\components\\pages\\admin\\services\\AddServiceType.vue' /* webpackChunkName: "components/pages-admin-services-add-service-type" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesChangeType = () => import('../..\\components\\pages\\admin\\services\\ChangeType.vue' /* webpackChunkName: "components/pages-admin-services-change-type" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesDeletePropertyImage = () => import('../..\\components\\pages\\admin\\services\\DeletePropertyImage.vue' /* webpackChunkName: "components/pages-admin-services-delete-property-image" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminServicesEditProperty = () => import('../..\\components\\pages\\admin\\services\\EditProperty.vue' /* webpackChunkName: "components/pages-admin-services-edit-property" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminTimeTableExportModal = () => import('../..\\components\\pages\\admin\\timeTable\\ExportModal.vue' /* webpackChunkName: "components/pages-admin-time-table-export-modal" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminTimeTableFilterServiceAndTime = () => import('../..\\components\\pages\\admin\\timeTable\\FilterServiceAndTime.vue' /* webpackChunkName: "components/pages-admin-time-table-filter-service-and-time" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminTimeTableFilterServices = () => import('../..\\components\\pages\\admin\\timeTable\\FilterServices.vue' /* webpackChunkName: "components/pages-admin-time-table-filter-services" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminTimeTableFilter = () => import('../..\\components\\pages\\admin\\timeTable\\TimeTableFilter.vue' /* webpackChunkName: "components/pages-admin-time-table-filter" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminTimeTableTabs = () => import('../..\\components\\pages\\admin\\timeTable\\TimeTableTabs.vue' /* webpackChunkName: "components/pages-admin-time-table-tabs" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminUsersEditFileNumber = () => import('../..\\components\\pages\\admin\\users\\EditFileNumber.vue' /* webpackChunkName: "components/pages-admin-users-edit-file-number" */).then(c => wrapFunctional(c.default || c))
export const PagesAdminUsersUserCard = () => import('../..\\components\\pages\\admin\\users\\UserCard.vue' /* webpackChunkName: "components/pages-admin-users-user-card" */).then(c => wrapFunctional(c.default || c))

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
