const middleware = {}

middleware['checkUser'] = require('..\\middleware\\checkUser.js')
middleware['checkUser'] = middleware['checkUser'].default || middleware['checkUser']

export default middleware
